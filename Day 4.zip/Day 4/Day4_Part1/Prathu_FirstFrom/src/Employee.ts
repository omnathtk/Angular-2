export interface Employee{
	empName:string,
	empAge:number,
	empEmail:string
}