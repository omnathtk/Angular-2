import { Component, NgModule, enableProdMode,Inject} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule,FormGroup,FormControl, FormBuilder, Validators } from '@angular/forms'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Employee } from './Employee'

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl: 'src/model.component.html'
})

export class ModelFormComponent {
  empForm : FormGroup;
  emp:Employee;
  empName:FormControl;
  empEmail:FormControl;

  constructor(@Inject(FormBuilder) private builder:FormBuilder){
    this.builtForm();
  }
  private builtForm(){
    this.empForm = this.builder.group({
     empName:new FormControl('Prathu',
	 Validators.compose([
       Validators.required,
       Validators.minLength(4),
       Validators.maxLength(12),
       Validators.pattern(/^[a-z]+$/i)
     ])),
     empAge:new FormControl(21);  
	 
	 empEmail:new FromControl('mandawariya.prathu07@gmail.com',
	 Validators.compose([
	 
	 Validators.required,
	 Validators.email
	 
	 
	 
	 ]));
    });
  }
   
  onSubmitForm(){
     this.emp = this.empForm.value;
     alert(" Employee Name : "+this.emp.empName+ " \n" + " Employee Age : "+this.emp.empAge + "\n"  + "Email : " + this.emp.empEmail);
	}
}

@NgModule({
  imports:[ BrowserModule, ReactiveFormsModule ],
  declarations:[ ModelFormComponent ],
  bootstrap:[ ModelFormComponent ]
})
class AppModule{}


platformBrowserDynamic().bootstrapModule(AppModule);

  