import { Component,Injectable,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';
import {Employee} from 'src/addEmp/Employee'

@Component({
    template:`
	<div class="container">
	<table><tr>
	<td class="col-mg-4">
	<h1>You are Offline! Data will be saved once the server is up... </h1>
	</td>
    <td class="col-mg-4">
	<img src="src/success/offline.jpg"/>
	</td>
	</tr>
	</table>
	</div>
	<hr/>
	
    <button type="button" class="btn btn-primary" (click)='navigateToHome()'>Go to Home</button>`
})


@Injectable()
export class SuccessComponent {
    constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
       
    }
    navigateToHome():void{
        this.router.navigate(['/home']);
    }
}
