import { Component } from '@angular/core';

@Component({
    template:`
	<div class="container">
		<!-- TESTIMONIALS -->
		<section>
			<div class="row">
				<div class="col-md-12">
				<h1> EMS for Startups </h1>
					<blockquote class="text-justify">
					<p> We manage your employees information. Login to our Employee Management System to store your employee data! 
						An employee management system consists of crucial work-related and important personal information about an employee. In a nutshell, it is an online inventory of all employees of an organization
						Employees are the strength of any organization, and it is more so in case of a growing business. It is crucial to handle this aspect of your business well. A good employee management system can actually make a world of difference to an organization, especially true in case of startups and small businesses, where the focus should be on growing the business more than anything else.
						Human Resource Software to record various information in HR requirements. Buy off the shelf, or Intoweb will customise their software to suit your unique needs.
			        	You only need to purchase the modules you require, Intoweb can integrate with other third party systems to either feed or pull information.
					</p>
						
					</blockquote>
				</div>
				
			</div> <!-- end row -->
	`
})


export class HomeComponent {

}

