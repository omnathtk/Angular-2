import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { SeriesComponent } from './fibo/fibonacci.component';

enableProdMode();

@Component({
  selector: 'my-app',
  template:`<div>
			<div class="jumbotron">
			  <h1> My new Path Demo</h1>
			</div>
			<nav  class='nav navbar-default'>
			<div class='container-fluid'>
				<ul class='nav navbar-nav'>
					<li routerLinkActive="active">
						<a [routerLink]="['/home']" >Home</a>
					</li>
					<li routerLinkActive="active">
						<a [routerLink]="['getDetails',uid]">Get User Details</a>
					</li>
					<li routerLinkActive="active">
						<a [routerLink]="['generateSeries']">Fibonacci Series</a>
					</li>
				  </ul>
			</div>
			</nav>
            <div>
            <div class="container">
                <router-outlet></router-outlet>
            </div>
			<div class="jumbotron">
			  <h1> Copyright &copy; Capgemini</h1>
			</div>
			`
})

export class AppComponent {
uid:number=90;
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {path:'home',component:HomeComponent},
  {path:'getDetails/:userId',component:UserComponent},
  {path:'generateSeries',component:SeriesComponent}
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true })],
    declarations:[ AppComponent, HomeComponent, UserComponent,SeriesComponent ],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);