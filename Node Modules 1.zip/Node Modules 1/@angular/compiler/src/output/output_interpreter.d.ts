import * as o from './output_ast';
export declare function interpretStatements(statements: o.Statement[], resultVar: string): any;
