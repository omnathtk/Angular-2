
export interface IEmployee{
    empId : number;
    empName : string;
    empDOJ : Date
}