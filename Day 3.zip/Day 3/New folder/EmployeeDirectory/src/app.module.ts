import {NgModule} from '@angular/core';
import {AppComponent} from './app.component';
import { BrowserModule } from '@angular/platform-browser';
import {EmployeeService} from './services/employeeService';
import {FormsModule} from '@angular/forms';
import {SearchControlsComponent} from './search.component'
import {ResultsDisplayComponent} from './resultsDisp.component'
@NgModule({
    imports : [BrowserModule,FormsModule],
    declarations : [AppComponent], 
    bootstrap : [AppComponent]
    
})
//,SearchControlsComponent,ResultsDisplayComponent
export class AppModule{}