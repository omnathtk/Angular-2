import { Component } from '@angular/core';
import { DispComponent } from './disp.component';
import { Student } from './student';

@Component({
  selector: 'stud-parent',
  template: `<div>  
			  <h1>I'm Student component - Calling Display Component</h1>
			  <child-selector 
				  [data]='students' 
				  [type]='t'></child-selector>
			 </div>  <hr/>`

})
export class StudComponent {
t:string;
students:Student[];
constructor()
{
   this.students=[  
             {  name: 'Virat Kholi',grade:'A+' },    
             {  name: 'Yuvraj Singh',grade:'O' },    
			 {  name: 'MS Dhoni',grade:'A' }   		 
           ];
    this.t="stud"
 }
} 