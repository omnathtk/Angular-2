export interface Account{
    id:number,
	balance:number
}