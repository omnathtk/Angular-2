import { Component } from '@angular/core';
import { InnerComponent } from './inner.component';

@Component({
	selector: 'my-app',
	template:`
	<h1> Welcome from Parent </h1>
	<my-directive 
	[receiveAlternate]="details" 
	(anyName)="f1($event)">
	</my-directive>
	<h1> From Inner : {{result}}</h1>
	`
})

export class OuterComponent {
	result:string="NA";
	details = {
		msg:'Message Initially sent from Outer Component to Inner Component'
	}
	f1(greet:any){
		this.result = "Message Received from Inner Component : "+ greet;
	}
}