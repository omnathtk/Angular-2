import { Component,enableProdMode,NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {Component} from '@angular/core';
import { ParentComponent } from './parent';
import { ChildComponent } from './child';
enableProdMode();
//our root app component


@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <h1>Angular2 Lifecycle Hooks</h1>
      <my-parent [data]="test"></my-parent>
    </div>
  `,
  directives: [
    ParentComponent
  ]
})
export class App {
  test = 'ok';
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ ChildComponent,ParentComponent,App ],
	bootstrap:[ App ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  
  