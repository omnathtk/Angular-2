import {Component,Input,Output,EventEmitter} from '@angular/core';
import {ChildComponent } from './inner.component';

@Component({
  selector: 'my-app',
  template: `<div>  
				<h1>I'm a container component</h1>
				<child-selector (notify)='f1($event)'></child-selector>
				<h2> Output : {{op}}</h2>
				</div>`,
  directives: [ChildComponent]
})
export class ParentComponent { 
   op:string="first"; 
  f1(message:string):void {
    alert(message);
	this.op=message;
  }
}