import { Injectable,Inject } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Person } from './models/guest';

@Injectable()
export class PersonService{
    
    private url = 'http://localhost:8080/SpringMVCAngularJS/springAngularJS.web';
    
    constructor(@Inject(Http) private http:Http){
        
    }
    
    getPerson():Observable<Person>{
        return this.http.get(this.url).map((response:Response)=><Person>response.json()).catch(this.handleError);
    }
    
    private handleError(error:Response){
        console.log("In Error "+error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}