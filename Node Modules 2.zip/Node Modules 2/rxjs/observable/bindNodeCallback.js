"use strict";
var BoundNodeCallbackObservable_1 = require('./BoundNodeCallbackObservable');
exports.bindNodeCallback = BoundNodeCallbackObservable_1.BoundNodeCallbackObservable.create;
//# sourceMappingURL=bindNodeCallback.js.map