"use strict";
var WebSocketSubject_1 = require('./WebSocketSubject');
exports.webSocket = WebSocketSubject_1.WebSocketSubject.create;
//# sourceMappingURL=webSocket.js.map