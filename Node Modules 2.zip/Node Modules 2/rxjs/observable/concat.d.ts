import { concatStatic } from '../operator/concat';
export declare const concat: typeof concatStatic;
