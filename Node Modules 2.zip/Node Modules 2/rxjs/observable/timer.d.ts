import { TimerObservable } from './TimerObservable';
export declare const timer: typeof TimerObservable.create;
