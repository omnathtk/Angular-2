"use strict";
var merge_1 = require('../operator/merge');
exports.merge = merge_1.mergeStatic;
//# sourceMappingURL=merge.js.map