import { IfObservable } from './IfObservable';
export declare const _if: typeof IfObservable.create;
