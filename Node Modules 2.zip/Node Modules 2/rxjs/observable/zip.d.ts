import { zipStatic } from '../operator/zip';
export declare const zip: typeof zipStatic;
