import { PairsObservable } from './PairsObservable';
export declare const pairs: typeof PairsObservable.create;
