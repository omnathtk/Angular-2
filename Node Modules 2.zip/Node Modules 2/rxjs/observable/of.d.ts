import { ArrayObservable } from './ArrayObservable';
export declare const of: typeof ArrayObservable.of;
