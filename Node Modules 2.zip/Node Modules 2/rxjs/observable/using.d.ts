import { UsingObservable } from './UsingObservable';
export declare const using: typeof UsingObservable.create;
