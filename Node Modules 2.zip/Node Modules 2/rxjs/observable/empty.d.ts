import { EmptyObservable } from './EmptyObservable';
export declare const empty: typeof EmptyObservable.create;
