"use strict";
var ForkJoinObservable_1 = require('./ForkJoinObservable');
exports.forkJoin = ForkJoinObservable_1.ForkJoinObservable.create;
//# sourceMappingURL=forkJoin.js.map