"use strict";
var concat_1 = require('../operator/concat');
exports.concat = concat_1.concatStatic;
//# sourceMappingURL=concat.js.map