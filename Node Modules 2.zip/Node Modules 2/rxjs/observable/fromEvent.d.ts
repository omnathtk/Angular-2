import { FromEventObservable } from './FromEventObservable';
export declare const fromEvent: typeof FromEventObservable.create;
