import { mergeStatic } from '../operator/merge';
export declare const merge: typeof mergeStatic;
