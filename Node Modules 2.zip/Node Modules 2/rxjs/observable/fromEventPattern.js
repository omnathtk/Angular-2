"use strict";
var FromEventPatternObservable_1 = require('./FromEventPatternObservable');
exports.fromEventPattern = FromEventPatternObservable_1.FromEventPatternObservable.create;
//# sourceMappingURL=fromEventPattern.js.map