"use strict";
var zip_1 = require('../operator/zip');
exports.zip = zip_1.zipStatic;
//# sourceMappingURL=zip.js.map