"use strict";
var IntervalObservable_1 = require('./IntervalObservable');
exports.interval = IntervalObservable_1.IntervalObservable.create;
//# sourceMappingURL=interval.js.map