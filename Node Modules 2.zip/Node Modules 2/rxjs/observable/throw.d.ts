import { ErrorObservable } from './ErrorObservable';
export declare const _throw: typeof ErrorObservable.create;
