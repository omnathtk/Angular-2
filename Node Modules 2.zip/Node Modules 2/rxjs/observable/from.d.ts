import { FromObservable } from './FromObservable';
export declare const from: typeof FromObservable.create;
