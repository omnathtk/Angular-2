"use strict";
var Observable_1 = require('../../Observable');
var repeatWhen_1 = require('../../operator/repeatWhen');
Observable_1.Observable.prototype.repeatWhen = repeatWhen_1.repeatWhen;
//# sourceMappingURL=repeatWhen.js.map