export declare function ReflectHasMetadataInvalidTarget(): void;
export declare function ReflectHasMetadataWithoutTargetKeyWhenNotDefined(): void;
export declare function ReflectHasMetadataWithoutTargetKeyWhenDefined(): void;
export declare function ReflectHasMetadataWithoutTargetKeyWhenDefinedOnPrototype(): void;
export declare function ReflectHasMetadataWithTargetKeyWhenNotDefined(): void;
export declare function ReflectHasMetadataWithTargetKeyWhenDefined(): void;
export declare function ReflectHasMetadataWithTargetKeyWhenDefinedOnPrototype(): void;
