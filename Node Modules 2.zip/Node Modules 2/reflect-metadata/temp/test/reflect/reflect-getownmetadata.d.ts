export declare function ReflectGetOwnMetadataInvalidTarget(): void;
export declare function ReflectGetOwnMetadataWithoutTargetKeyWhenNotDefined(): void;
export declare function ReflectGetOwnMetadataWithoutTargetKeyWhenDefined(): void;
export declare function ReflectGetOwnMetadataWithoutTargetKeyWhenDefinedOnPrototype(): void;
export declare function ReflectGetOwnMetadataWithTargetKeyWhenNotDefined(): void;
export declare function ReflectGetOwnMetadataWithTargetKeyWhenDefined(): void;
export declare function ReflectGetOwnMetadataWithTargetKeyWhenDefinedOnPrototype(): void;
