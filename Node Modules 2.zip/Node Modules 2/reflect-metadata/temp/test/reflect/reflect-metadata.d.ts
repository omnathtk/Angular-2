export declare function ReflectMetadataReturnsDecoratorFunction(): void;
export declare function ReflectMetadataDecoratorThrowsWithInvalidTargetWithTargetKey(): void;
export declare function ReflectMetadataDecoratorThrowsWithInvalidTargetWithoutTargetKey(): void;
export declare function ReflectMetadataDecoratorSetsMetadataOnTargetWithoutTargetKey(): void;
export declare function ReflectMetadataDecoratorSetsMetadataOnTargetWithTargetKey(): void;
