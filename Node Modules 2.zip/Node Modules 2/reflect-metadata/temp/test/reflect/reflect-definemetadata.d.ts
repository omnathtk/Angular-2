export declare function ReflectDefineMetadataInvalidTarget(): void;
export declare function ReflectDefineMetadataValidTargetWithoutTargetKey(): void;
export declare function ReflectDefineMetadataValidTargetWithTargetKey(): void;
