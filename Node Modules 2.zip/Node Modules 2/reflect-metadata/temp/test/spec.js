"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./reflect/reflect-decorate"));
__export(require("./reflect/reflect-metadata"));
__export(require("./reflect/reflect-definemetadata"));
__export(require("./reflect/reflect-hasownmetadata"));
__export(require("./reflect/reflect-hasmetadata"));
__export(require("./reflect/reflect-getownmetadata"));
__export(require("./reflect/reflect-getmetadata"));
__export(require("./reflect/reflect-getownmetadatakeys"));
__export(require("./reflect/reflect-getmetadatakeys"));
__export(require("./reflect/reflect-deletemetadata"));
//# sourceMappingURL=spec.js.map