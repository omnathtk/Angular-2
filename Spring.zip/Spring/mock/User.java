package demo.mock;

public class User {
String username, password;
}
