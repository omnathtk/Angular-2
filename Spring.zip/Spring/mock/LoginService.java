package demo.mock;

public interface LoginService {
boolean login(String username, String password);
}
