import { Component,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';
@Component({
    templateUrl:'src/home/home.component.html';
})


export class HomeComponent {
errorMsg:string;
constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
    }
onSubmit(name:string,pwd:string){
		var n1=localStorage.getItem("uname");
		var n2=localStorage.getItem("pwd");
		if(name==n1 && pwd==n2)
		{
		this.errorMsg="";
		   this.router.navigate(['/userhome']);
		  }
		else
		{
		   this.errorMsg="Invalid username and password";
		   this.router.navigate(['/home']);
		   }
}
registerHere():void{
   this.router.navigate(['/register']);
}
}

