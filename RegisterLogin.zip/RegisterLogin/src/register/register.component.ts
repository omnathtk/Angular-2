import { Component,Inject,Injectable } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';
@Component({
    templateUrl:'src/register/register.component.html';
})

export class RegisterComponent {
username:string;
password:string;
mail:string;
constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         
    }
onSubmit(uname:string,pwd:string){
   localStorage.setItem("uname",uname);
   localStorage.setItem("pwd",pwd);
   this.router.navigate(['/success']);
}

}

